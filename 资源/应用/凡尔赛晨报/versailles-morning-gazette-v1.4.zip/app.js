(()=>{
  'use strict';
  const sdk=()=>window.AiPhone||window.AiPhoneApp;
  const $=id=>document.getElementById(id);
  const views=['homeView','loadingView','articleView','historyView','errorView'];
  const state={launch:{},characters:[],records:[],current:null,busy:false,loadingTimer:null,loadingStep:0};
  const perspectiveNames={neutral:'隐匿起居注官',user:'你的亲友团',char:'TA 近臣团',gossip:'吃瓜侍从'};
  const perspectivePrompts={
    neutral:'你是宫廷起居注官，表面克制公允，实际非常会从细节里看出关系气氛。',
    user:'你是对方的亲友团，天然偏袒对方，喜欢替对方撑腰，也会从角色言行里暗戳戳找糖。成稿里绝不能把对方称作“用户”或“User”。',
    char:'你是角色的近臣团，天然偏袒角色，会替TA解释，也会不小心泄露TA对对方的在意。成稿里绝不能把对方称作“用户”或“User”。',
    gossip:'你是宫里最灵通的吃瓜侍从，语言最活泼，会添油加醋地讲述，但绝不捏造没有发生过的事实。'
  };
  function show(id){views.forEach(v=>$(v).classList.toggle('active',v===id));window.scrollTo(0,0)}
  function toast(t){try{sdk().ui.toast(t)}catch(_){}}
  function list(v){return Array.isArray(v)?v:Array.isArray(v?.items)?v.items:[]}
  function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
  function today(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
  function todayFancy(){const d=new Date();const m=['JANVIER','FÉVRIER','MARS','AVRIL','MAI','JUIN','JUILLET','AOÛT','SEPTEMBRE','OCTOBRE','NOVEMBRE','DÉCEMBRE'][d.getMonth()];return `${d.getDate()} ${m} ${d.getFullYear()}`}
  function selectedCharacter(){return state.characters.find(c=>String(c.id)===String($('characterSelect').value))||state.characters[0]||null}
  function selectedPerspective(){return document.querySelector('input[name="perspective"]:checked')?.value||'neutral'}
  function parseJson(text){let s=String(text||'').trim().replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'');const a=s.indexOf('{'),b=s.lastIndexOf('}');if(a<0||b<a)throw new Error('没有找到 JSON');return JSON.parse(s.slice(a,b+1))}
  function cleanModelText(value,{paragraphs=false}={}){
    let s=String(value??'');
    // 模型偶尔会擅自返回 HTML 换行。统一转回纯文本，避免 <br><br> 被印进报纸。
    s=s.replace(/<br\s*\/?\s*>/gi,'\n');
    // 其余 HTML 标签一律剥掉；成稿只允许纯文本。
    s=s.replace(/<\/?[a-z][^>]*>/gi,'');
    // 处理最常见的 HTML 实体，避免它们以源码形式出现。
    s=s.replace(/&nbsp;/gi,' ').replace(/&amp;/gi,'&').replace(/&lt;/gi,'<').replace(/&gt;/gi,'>').replace(/&quot;/gi,'\"').replace(/&#39;/gi,"'");
    s=s.replace(/\r\n?/g,'\n');
    if(paragraphs){
      s=s.replace(/[ \t]+\n/g,'\n').replace(/\n[ \t]+/g,'\n').replace(/\n{3,}/g,'\n\n');
    }else{
      s=s.replace(/\s+/g,' ');
    }
    return s.trim();
  }
  function normalizeArticle(o){
    const status=String(o?.status||'ok');
    return {status,title:cleanModelText(o?.title),subtitle:cleanModelText(o?.subtitle),body:cleanModelText(o?.body,{paragraphs:true}),trivia:cleanModelText(o?.trivia),rating:cleanModelText(o?.rating),verdict:cleanModelText(o?.verdict),tags:Array.isArray(o?.tags)?o.tags.map(v=>cleanModelText(v)).filter(Boolean).slice(0,5):[],sourceSummary:cleanModelText(o?.sourceSummary,{paragraphs:true}),reason:cleanModelText(o?.reason,{paragraphs:true})};
  }
  function startLoading(characterName){
    const lines=[
      `正在翻阅 ${characterName||'TA'} 与你的近期密谈`,
      '线人正在核对近几日口供…',
      '从只言片语里挑选最值得上头版的一桩…',
      '起居注官正在把细节写进小本本…',
      '宫廷编辑部正在夸张措辞，但不许捏造事实…',
      '排字工正在给标题加一点戏剧性…',
      '密报即将付梓，请再等片刻…'
    ];
    clearInterval(state.loadingTimer);state.loadingStep=0;$('loadingLine').textContent=lines[0];
    state.loadingTimer=setInterval(()=>{state.loadingStep=(state.loadingStep+1)%lines.length;$('loadingLine').textContent=lines[state.loadingStep]},1800);
  }
  function stopLoading(){if(state.loadingTimer){clearInterval(state.loadingTimer);state.loadingTimer=null}}
  async function persistCurrentSilently(){
    const a=state.current;if(!a||a.id)return true;
    try{
      const saved=await sdk().db.create('gazettes',a);
      a.id=saved?.id||saved?.data?.id||null;
      state.records.unshift({...a});
      $('saveBtn').textContent='已收藏';
      return true;
    }catch(e){
      $('saveBtn').textContent='收藏';
      return false;
    }
  }
  async function generateArticle(){
    if(state.busy)return;
    const character=selectedCharacter(); if(!character){toast('先选一个角色');return}
    state.busy=true;show('loadingView');startLoading(character.name||'TA');
    const p=selectedPerspective();
    const instruction=`你正在制作一份“凡尔赛晨报”：把当前角色与对方最近真实发生的聊天内容，改写成18世纪宫廷八卦报纸。${perspectivePrompts[p]}

最重要的事实规则：
1. 优先使用“今天”对方与当前角色真实聊过、做过、提到过的具体事件。
2. 如果今天的内容太少，就自然向前读取你当前可访问到的最近聊天，直到找到足够具体、适合写成一篇宫廷八卦的素材；不要求必须发生在今天。
3. 只允许使用你实际能从近期聊天上下文中确认的事实。不要凭角色设定、长期记忆、常识或想象补造事件。
4. 若近期聊天里有多个小事件，可以挑最有戏剧性的一件做主线，并把其他真实细节写成旁枝或“宫廷碎语”。
5. 只有在你确实完全无法访问任何近期聊天内容时，才返回 status="no_context"。不要因为“今天没料”就返回 no_context。
6. 可以夸张措辞、宫廷化比喻、阴阳怪气，但事实核心必须真实。
7. 成稿绝不能出现“用户”或“User”来称呼对方。若近期聊天或当前角色上下文里能确认对方平时被怎样称呼（例如名字、昵称），优先自然使用那个称呼；如果无法确认，就使用适合宫廷报纸语气的“殿下”“阁下”“那位大人”等代称，并在同一篇里自然变化，避免机械重复。角色称呼使用“${character.name||'角色'}”或其在近期聊天中明确出现的自然称呼，不要凭空改名。
8. 正文半文半白、华丽但易读，约350-650字。\n9. 所有字段都必须是纯文本。正文只能用两个换行符表示分段，严禁输出 <br>、<p>、<div> 或任何 HTML 标签。

只输出合法 JSON，不要 Markdown：{"status":"ok 或 no_context","title":"夸张宫廷标题","subtitle":"一句副标题","body":"正文，用\n\n分段","trivia":"宫廷碎语，一条最有趣的细节","rating":"如：五颗粉钻·绝对深情级 / 三枚羽毛·捕风捉影级","verdict":"一句今日判词","tags":["甜蜜","拌嘴"],"sourceSummary":"用1-3句列出本篇实际依据的近期事件，便于核对","reason":"若 no_context，说明原因"}`;
    try{
      const res=await sdk().ai.generate({characterId:character.id,appTags:['palace-gazette','today-chat'],messages:[{role:'user',content:'请从我们最近的真实聊天里挑一件最值得八卦的事写成宫廷晨报。优先今天；如果今天内容少，就往前读最近消息。只写你实际看得到的内容，不要补造。',createdAt:new Date().toISOString()}],instruction});
      let obj;try{obj=parseJson(res?.text||res?.content||String(res||''))}catch(_){
        const raw=res?.text||res?.content||String(res||'');
        const fix=await sdk().ai.generate({characterId:character.id,appTags:['palace-gazette','json-repair'],messages:[{role:'assistant',content:raw,createdAt:new Date().toISOString()}],instruction:'把刚才内容只整理成合法 JSON，字段必须是 status,title,subtitle,body,trivia,rating,verdict,tags,sourceSummary,reason。不得新增事实。所有字段只用纯文本，body 用两个换行符分段，禁止任何 HTML 标签。只输出 JSON。'});
        obj=parseJson(fix?.text||fix?.content||String(fix||''));
      }
      const a=normalizeArticle(obj);
      if(a.status!=='ok'||!a.title||!a.body){showError('暂未觅得密闻',a.reason||'暂时没有读取到足够的近期聊天内容。');return}
      state.current={...a,id:null,characterId:String(character.id),characterName:character.name||'角色',perspective:p,perspectiveName:perspectiveNames[p],date:today(),createdAt:new Date().toISOString(),memorySaved:false};
      await persistCurrentSilently();
      renderArticle(state.current);show('articleView');
    }catch(e){showError('抄报官摔了一跤',e?.message||String(e))}finally{stopLoading();state.busy=false}
  }
  function renderArticle(a){
    $('articleIssue').textContent=`NO. ${380+state.records.length}`;$('articleDate').textContent=todayFancy();$('articlePerspective').textContent=a.perspectiveName;
    $('articleTitle').textContent=a.title;$('articleSubtitle').textContent=a.subtitle;$('articleBody').innerHTML=a.body.split(/\n\s*\n/).filter(Boolean).map(p=>`<p>${esc(p)}</p>`).join('');$('articleTrivia').textContent=a.trivia;$('articleRating').textContent=a.rating;$('articleVerdict').textContent=a.verdict;$('articleTags').innerHTML=a.tags.map(t=>`<span>${esc(t)}</span>`).join('');$('rememberToggle').checked=true;$('saveBtn').textContent=a.id?'已收藏':'收藏';
  }
  async function remember(a){if(!a||a.memorySaved||!$('rememberToggle').checked)return;const summary=`凡尔赛晨报记录了对方与${a.characterName}在${a.date}的互动。依据：${a.sourceSummary}。晨报标题：${a.title}。今日判词：${a.verdict}`.slice(0,1800);await sdk().memory.addTimeline({characterId:a.characterId,appLabel:'凡尔赛晨报',detail:'palace_gazette_daily',summary,appEventId:`palace-gazette-${a.id||Date.now()}`,data:{recordId:a.id||'',date:a.date,tags:a.tags}});a.memorySaved=true;if(a.id)await sdk().db.update('gazettes',a.id,{memorySaved:true})}
  async function saveCurrent(){const a=state.current;if(!a)return;if(!a.id){const saved=await sdk().db.create('gazettes',a);a.id=saved?.id||saved?.data?.id||null;state.records.unshift({...a});$('saveBtn').textContent='已收藏';toast('这份晨报已经入库')}else toast('已经收藏过了');try{await remember(a)}catch(e){toast(`晨报已保存，但角色记忆写入失败：${e?.message||e}`)}}
  async function loadRecords(){try{state.records=list(await sdk().db.list('gazettes',{limit:200})).sort((a,b)=>String(b.createdAt||'').localeCompare(String(a.createdAt||'')))}catch(_){state.records=[]}}
  async function renderHistory(){await loadRecords();const box=$('historyList');box.innerHTML='';$('emptyHistory').classList.toggle('hidden',state.records.length>0);for(const r of state.records){const item=document.createElement('article');item.className='history-item';item.innerHTML=`<small>${esc(r.date||String(r.createdAt||'').slice(0,10))} · ${esc(r.characterName||'角色')} · ${esc(r.perspectiveName||'')}</small><h3>${esc(r.title||'未命名宫闻')}</h3><p>${esc(r.verdict||r.subtitle||'')}</p>`;item.addEventListener('click',()=>{state.current={...r};renderArticle(state.current);show('articleView')});box.appendChild(item)}show('historyView')}
  function showError(title,text){$('errorTitle').textContent=title;$('errorText').textContent=text;show('errorView')}
  async function init(){
    $('todayLabel').textContent=todayFancy();
    try{state.launch=await sdk().app.getLaunchContext()}catch(_){state.launch={}}
    try{state.characters=list(await sdk().characters.list())}catch(_){state.characters=[]}
    const sel=$('characterSelect');sel.innerHTML=state.characters.length?state.characters.map(c=>`<option value="${esc(c.id)}">${esc(c.name||c.id)}</option>`).join(''):'<option value="">未读取到角色</option>';
    if(state.launch?.characterId&&state.characters.some(c=>String(c.id)===String(state.launch.characterId)))sel.value=String(state.launch.characterId);
    await loadRecords();$('issueNo').textContent=`NO. ${380+state.records.length}`;
    $('generateBtn').onclick=generateArticle;$('backBtn').onclick=()=>show('homeView');$('historyBackBtn').onclick=()=>show('homeView');$('historyBtn').onclick=renderHistory;$('saveBtn').onclick=()=>saveCurrent().catch(e=>showError('收藏失败',e?.message||String(e)));$('regenerateBtn').onclick=()=>{show('homeView');toast('换个线人视角，再生成一次')};$('errorBackBtn').onclick=()=>show('homeView');
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
