/* ============================================================
 * 答案之书 · The Book of Answers
 * 共 200 页，两种翻开方式：
 *   A. 随机翻一页   B. 输入页码（1–200）
 * 状态机：closed → choose（翻开，选择方式）→ flipping → revealed
 * ============================================================ */
(function () {
  "use strict";

  /* ---------- 答案池：共 200 条，索引 + 1 = 页码 ---------- */
  var TOTAL_PAGES = 200;
  var ANSWERS = [
    "是的，去试试看吧。",
    "答案是肯定的。",
    "再耐心等一等。",
    "现在还不是时候。",
    "跟随你的直觉。",
    "相信你的第一感觉。",
    "别犹豫，就是现在。",
    "这件事值得你去做。",
    "换个角度再看看。",
    "答案就在你身边。",
    "放下执念，顺其自然。",
    "大胆一点，再大胆一点。",
    "时机尚未成熟。",
    "相信过程，别怕结果。",
    "先静下来，听听内心。",
    "不要问，去做。",
    "会比你想象中更快到来。",
    "保持耐心，好运会来。",
    "你的直觉已经告诉你答案了。",
    "你值得拥有更好的。",
    "再坚持一下，就到了。",
    "允许自己慢下来。",
    "试着换个方向走。",
    "命运站在你这边。",
    "它需要更多时间。",
    "行动永远比空想有用。",
    "别害怕开口说出来。",
    "这一次会和以前不一样。",
    "答案是否定的，但路不止一条。",
    "水到渠成，别强求。",
    "顺着风的方向走。",
    "你会得到你想要的回应。",
    "慢一点，再慢一点。",
    "抓住那个一闪而过的念头。",
    "有些事，过程比答案更重要。",
    "它正在来的路上。",
    "把问题交给明天。",
    "答案会在意想不到的地方出现。",
    "先照顾好自己。",
    "是的，但要用新的方式。",
    "别回头，往前走。",
    "留一点悬念给生活。",
    "这是一次值得的冒险。",
    "安静下来，答案会来找你。",
    "不必勉强，自有安排。",
    "你比自己想的更强大。",
    "一点点改变就能带来转机。",
    "大胆说出你的愿望。",
    "该放下的时候到了。",
    "星光会为你指路。",
    "把担忧交给风吧。",
    "今天适合做个新决定。",
    "答案在别处，也在你心里。",
    "一切都会慢慢好起来。",
    "勇敢的人先享受世界。",
    "你期待的正在靠近。",
    "再努力一点点。",
    "退一步海阔天空。",
    "相信自己的判断。",
    "现在就开始吧。",
    "它值得你再试一次。",
    "你的顾虑是多余的。",
    "准备好迎接变化。",
    "有些答案需要时间检验。",
    "别把力气花在担忧上。",
    "试着说出你的想法。",
    "旧的门关上，新的窗会开。",
    "相信那个让你心动的瞬间。",
    "先处理心情，再处理事情。",
    "答案比你想的更简单。",
    "往前走，别低头。",
    "给彼此一点空间。",
    "你的坚持不会白费。",
    "温柔一点，对自己也是。",
    "是时候迈出那一步了。",
    "别忘了你最初的愿望。",
    "黑夜再长，天也会亮。",
    "这件事急不来。",
    "去相信，去行动。",
    "结果会证明你的选择。",
    "问问自己真正想要什么。",
    "有些缘分，值得再等。",
    "别让犹豫偷走你的时间。",
    "答案藏在细节里。",
    "大胆想象，然后脚踏实地。",
    "你已经准备好了。",
    "该表达的时候别沉默。",
    "一切刚刚好。",
    "顺势而为，别逆流硬闯。",
    "学会拒绝也是一种成长。",
    "用心去感受，别用脑子分析。",
    "这条路，走就对了。",
    "有些问题本身，就是答案。",
    "你担心的事大概率不会发生。",
    "给自己一个机会。",
    "别比较，走自己的节奏。",
    "远方有更好的风景。",
    "现在正是好时候。",
    "事情会比预想中顺利。",
    "跟着光走。",
    "你的付出正在被看见。",
    "别把所有问题都揽在自己身上。",
    "答案需要你亲自去验证。",
    "慢就是快。",
    "有些决定，做了才知道对错。",
    "放下手机，去散个步吧。",
    "你缺的不是答案，是勇气。",
    "适合你的，才是最好的。",
    "别怕做那个先开口的人。",
    "时间会给你公正的回答。",
    "换个环境，思路就开了。",
    "值得的人，经得起等待。",
    "别把答案交给焦虑。",
    "小步快跑，别求一步到位。",
    "你的直觉从不骗你。",
    "该认真时认真，该放下时放下。",
    "明天会比今天好一点。",
    "别着急，你正在路上。",
    "有些答案，要翻过几页才看得到。",
    "相信你所相信的。",
    "与其猜测，不如直接问。",
    "这是你的转折点。",
    "别为还没发生的事提前买单。",
    "好故事需要铺垫。",
    "你已经有答案了，只是需要确认。",
    "把注意力放在你能改变的事上。",
    "有些门不会开，但窗口一直在。",
    "值得等待的，一定值得。",
    "别让别人的节奏打乱你。",
    "答案不会主动来，去迎接它。",
    "你比自己以为的更接近目标。",
    "试着温柔地坚持。",
    "有些事，想太多反而看不清。",
    "现在就给那个人发消息吧。",
    "别把最好的一次留给最后。",
    "你的能量比想象中大。",
    "顺其自然，水到渠成。",
    "花会开，但需要季节。",
    "别怕改变，它带来新生。",
    "你走的每一步都算数。",
    "有些答案需要放下自尊才能得到。",
    "静水流深，低调前行。",
    "别急着要结果，先享受过程。",
    "相信时间，也相信你自己。",
    "它可能比你预期的更好。",
    "是时候整理一下房间和心情了。",
    "答案不在远方，在当下。",
    "别低估习惯的力量。",
    "有些人值得再给一次机会。",
    "你担心的那件事，会有转机。",
    "向前走，别在原点打转。",
    "学会把大问题拆成小步。",
    "你的直觉正在给你信号。",
    "别问值不值得，问愿不愿意。",
    "有些答案，睡一觉就有了。",
    "放手也是一种拥有。",
    "现在做，比完美地做更重要。",
    "答案需要一点耐心发酵。",
    "别怕孤独，它是你的养分。",
    "你正在成为更好的自己。",
    "有些路，只有走过去才知道。",
    "别急着证明自己。",
    "好的改变，从小的行动开始。",
    "答案在行动中，不在想象里。",
    "别让过去的影子遮住今天。",
    "你值得被认真对待。",
    "有些事，答案就在下一句。",
    "保持好奇，答案会追着你跑。",
    "别把所有鸡蛋放一个篮子。",
    "真诚，是最好的策略。",
    "答案会随着你的成长而清晰。",
    "别怕犯错，那是最好的老师。",
    "你想要的，正在向你靠近。",
    "有些答案，需要勇气才敢看。",
    "别让自己后悔没试过。",
    "把今天过好，明天自有答案。",
    "你的选择比条件更重要。",
    "别着急，花开有时。",
    "有些缘分，点到为止。",
    "答案就在你的行动里。",
    "先爱自己，再谈其他。",
    "别怕从头开始。",
    "答案会在对的时间出现。",
    "有些问题，答案是你自己。",
    "别让焦虑定义你的选择。",
    "你的感受是重要的。",
    "有些答案，藏在朋友的提醒里。",
    "大胆一点，世界会给你回应。",
    "别把简单的事想复杂。",
    "你已经在路上了。",
    "有些答案，需要时间来证明。",
    "别辜负现在的自己。",
    "答案可能就在你的手边。",
    "去创造，别只等待。",
    "有些事，值得再坚持一次。",
    "你的内心比你想象中清楚。",
    "别怕说出你真正想要的。",
    "答案正在赶来见你。",
    "这一刻，就是最好的时机。",
    "相信自己，你已经很好了。"
  ];

  /* ---------- DOM 引用 ---------- */
  var book        = document.querySelector(".book");
  var hintEl      = document.querySelector(".hint");
  var pages       = Array.prototype.slice.call(document.querySelectorAll(".page"));
  var cover       = document.querySelector(".cover");
  var answerPage  = document.querySelector(".answer-page");
  var choosePanel = document.getElementById("choosePanel");
  var answerContent = document.getElementById("answerContent");
  var answerText  = document.getElementById("answerText");
  var pageNumShow = document.getElementById("pageNumShow");
  var pageInput   = document.getElementById("pageNum");
  var inputTip    = document.getElementById("inputTip");
  var askAgain    = document.querySelector(".ask-again");
  var starsBox    = document.querySelector(".stars");

  /* ---------- 状态 ---------- */
  var STATE = { CLOSED: "closed", CHOOSE: "choose", FLIPPING: "flipping", REVEALED: "revealed" };
  var state = STATE.CLOSED;
  var busy = false;
  var lastPage = 0;

  /* ---------- 提示文案 ---------- */
  var HINTS = {};
  HINTS[STATE.CLOSED]   = "在心底默念你的问题，然后<b>轻触书本</b>";
  HINTS[STATE.CHOOSE]   = "选择翻开方式：<b>随机翻页</b>，或<b>输入页码</b>";
  HINTS[STATE.FLIPPING] = "书页沙沙翻动，答案正在浮现…";

  /* ---------- 工具 ---------- */
  function answerAt(page) { return ANSWERS[(page - 1) % TOTAL_PAGES]; }
  function randomPage()   { return 1 + Math.floor(Math.random() * TOTAL_PAGES); }
  function showTip(text, ok) {
    inputTip.textContent = text || "";
    inputTip.classList.toggle("ok", !!ok);
    inputTip.classList.remove("hidden");
  }
  function hideTip() { inputTip.classList.add("hidden"); }

  /* ---------- 渲染 ---------- */
  function render() {
    if (state === STATE.REVEALED) {
      hintEl.innerHTML = "第 <b>" + lastPage + "</b> 页 · 就是此刻的答案";
    } else {
      hintEl.innerHTML = HINTS[state] || HINTS[STATE.CLOSED];
    }
    if (state === STATE.REVEALED) {
      askAgain.classList.add("visible");
      book.setAttribute("aria-label", "第" + lastPage + "页，答案是：" + answerText.textContent + "，点击合上书再问一次");
    } else {
      askAgain.classList.remove("visible");
      book.setAttribute("aria-label", "答案之书，点击翻开获取答案");
    }
  }

  /* ---------- 动作 ---------- */
  function openBook() {
    // 打开：展示选择面板
    answerContent.classList.add("hidden");
    choosePanel.classList.remove("hidden");
    pageInput.value = "";
    hideTip();
    cover.classList.add("is-open");
    state = STATE.CHOOSE;
    render();
  }

  function closeBook() {
    answerContent.classList.remove("show", "hidden");
    answerContent.classList.add("hidden");
    choosePanel.classList.remove("hidden");
    pageInput.value = "";
    hideTip();
    pages.forEach(function (p, i) {
      setTimeout(function () { p.classList.remove("flipped"); }, i * 60);
    });
    cover.classList.remove("is-open");
    state = STATE.CLOSED;
    render();
  }

  function flipToAnswer(page) {
    state = STATE.FLIPPING;
    render();
    choosePanel.classList.add("hidden");
    answerContent.classList.remove("hidden", "show");
    answerContent.classList.remove("show");
    // 依次快速翻页
    pages.forEach(function (p, i) {
      setTimeout(function () { p.classList.add("flipped"); }, 150 + i * 100);
    });
    var doneAt = 150 + pages.length * 100 + 420;
    setTimeout(function () {
      lastPage = page;
      pageNumShow.textContent = page;
      answerText.textContent = answerAt(page);
      answerContent.classList.add("show");
      state = STATE.REVEALED;
      busy = false;
      render();
      // 通知小手机宿主：角色回应这次翻出的答案
      onAnswerRevealed(answerAt(page));
    }, doneAt);
  }

  /* ============================================================
   * AiPhone 集成：答案揭晓后，把这件事写入聊天历史并触发角色回复
   * （仅在 window.AiPhone 存在的宿主环境中生效，普通浏览器静默跳过）
   * ============================================================ */
  async function onAnswerRevealed(answer) {
    try {
      if (!window.AiPhone) return;
      // 1. 获取当前交互的角色和用户昵称
      var characters = await window.AiPhone.characters.list();
      var launchContext = await window.AiPhone.app.getLaunchContext();
      var characterId = (launchContext && launchContext.characterId) ||
                        (characters && characters[0] ? characters[0].id : null);
      if (!characterId) {
        console.warn("未找到有效角色");
        return;
      }
      var userProfile = await window.AiPhone.user.getProfile({ characterId: characterId });
      var userName = (userProfile && userProfile.name) || "你";
      // 2. 把翻出的答案作为用户事件写入聊天历史
      // 提示词里明确告知 AI：用户翻到了答案，但没有透露问了什么
      await window.AiPhone.chat.writeHistory({
        characterId: characterId,
        role: "user",
        content: "[系统通知：" + userName + "刚刚在《答案之书》App中默默许愿并翻出了答案：“" + answer + "”。TA并没有告诉你TA问了什么问题。]"
      });
      // 3. 触发角色在聊天室主动开口
      await window.AiPhone.chat.requestReply({ characterId: characterId });
      // 4. 给用户弹个提示
      await window.AiPhone.ui.toast("对方似乎注意到了你的答案之书…");
    } catch (err) {
      console.error("通知角色失败:", err);
    }
  }

  /* ---------- 交互 ---------- */
  function onBookTap() {
    if (busy) return;
    if (state === STATE.CLOSED) {
      busy = true;
      openBook();
      setTimeout(function () { busy = false; }, 1050);
    } else if (state === STATE.CHOOSE) {
      // 直接点击书 = 随机翻页
      busy = true;
      flipToAnswer(randomPage());
    } else if (state === STATE.REVEALED) {
      busy = true;
      closeBook();
      setTimeout(function () { busy = false; }, 1050);
    }
  }

  function submitPage() {
    var raw = pageInput.value.trim();
    if (!raw) { showTip("请输入页码"); return; }
    var n = Number(raw);
    if (!Number.isInteger(n) || n < 1 || n > TOTAL_PAGES) {
      showTip("请输入 1 – " + TOTAL_PAGES + " 之间的数字");
      return;
    }
    hideTip();
    busy = true;
    flipToAnswer(n);
  }

  function showPageInput() {
    hideTip();
    pageInput.closest(".page-input").classList.remove("hidden");
    pageInput.focus();
  }

  /* ---------- 事件绑定 ---------- */
  book.addEventListener("click", onBookTap);
  book.addEventListener("keydown", function (e) {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      onBookTap();
    }
  });
  askAgain.addEventListener("click", function () {
    if (busy) return;
    busy = true;
    closeBook();
    setTimeout(function () { busy = false; }, 1050);
  });

  /* 选择面板内按钮（阻止冒泡到 book） */
  choosePanel.addEventListener("click", function (e) {
    e.stopPropagation();
    var modeBtn = e.target.closest(".choice[data-mode]");
    if (modeBtn) {
      if (modeBtn.dataset.mode === "page") { showPageInput(); return; }
      // random
      if (busy) return;
      busy = true;
      flipToAnswer(randomPage());
      return;
    }
    if (e.target.closest(".go-btn")) {
      submitPage();
    }
  });
  pageInput.addEventListener("keydown", function (e) {
    e.stopPropagation();
    if (e.key === "Enter") { e.preventDefault(); submitPage(); }
  });

  /* ---------- 星尘 ---------- */
  function initStars() {
    var count = window.innerWidth < 768 ? 34 : 66;
    var frag = document.createDocumentFragment();
    for (var i = 0; i < count; i++) {
      var s = document.createElement("i");
      var size = 1 + Math.random() * 2;
      s.style.width = size + "px";
      s.style.height = size + "px";
      s.style.left = (Math.random() * 100).toFixed(2) + "%";
      s.style.top = (Math.random() * 100).toFixed(2) + "%";
      s.style.setProperty("--tw", (2.6 + Math.random() * 3.4).toFixed(2) + "s");
      s.style.setProperty("--td", (Math.random() * 4).toFixed(2) + "s");
      frag.appendChild(s);
    }
    starsBox.appendChild(frag);
  }

  /* ---------- 启动 ---------- */
  initStars();
  render();
})();
